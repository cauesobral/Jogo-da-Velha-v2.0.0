#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define TAM 3

void inicio_tabuleiro(char tabuleiro[TAM][TAM]) {
    for (int i = 0; i < TAM; i++) {
        for (int j = 0; j < TAM; j++) {
            tabuleiro[i][j] = ' ';
        }
    }
}

void mostrar_tabuleiro(char tabuleiro[TAM][TAM]) {
    for (int i = 0; i < TAM; i++) {
        printf(" %c | %c | %c \n", tabuleiro[i][0], tabuleiro[i][1], tabuleiro[i][2]);
        if (i < TAM - 1)
            printf("-----------\n");
    }
}

int verificar_vitoria(char tabuleiro[TAM][TAM], char simbolo) {
    for (int i = 0; i < TAM; i++) {
        if (tabuleiro[i][0] == simbolo && tabuleiro[i][1] == simbolo && tabuleiro[i][2] == simbolo)
            return 1;
        if (tabuleiro[0][i] == simbolo && tabuleiro[1][i] == simbolo && tabuleiro[2][i] == simbolo)
            return 1;
    }

    if (tabuleiro[0][0] == simbolo && tabuleiro[1][1] == simbolo && tabuleiro[2][2] == simbolo)
        return 1;
    if (tabuleiro[0][2] == simbolo && tabuleiro[1][1] == simbolo && tabuleiro[2][0] == simbolo)
        return 1;

    return 0;
}

int main() {
    char jogadorX[30], jogadorO[30];
    char tabuleiro[TAM][TAM];
    char jogar_novamente = 'S', mesmos_jogadores = 'N';
    int linha, coluna, turno;
    char simbolo;

    printf("-------------------------------------------\n");
    printf("| Bem vindo(a) ao Jogo da Velha!          |\n");
    printf("| Feito por Caue Roberto da Silva Sobral  |\n");
    printf("| Disciplina: Algoritmos                  |\n");
    printf("| Docente: Vitor Oliveira Kuribara        |\n");
    printf("-------------------------------------------\n");

    do {
        if (jogar_novamente != 'S' || mesmos_jogadores != 'S') {
            printf("Por favor, escreva o nome dos jogadores: \n\n");
            printf("Jogador X: ");
            fgets(jogadorX, 30, stdin);
            jogadorX[strcspn(jogadorX, "\n")] = '\0';
            printf("Jogador O: ");
            fgets(jogadorO, 30, stdin);
            jogadorO[strcspn(jogadorO, "\n")] = '\0';
        }

        inicio_tabuleiro(tabuleiro);
        simbolo = 'X';
        turno = 0;

        system("cls");

        printf("Jogadores cadastrados:\n");
        printf("X: %s\n", jogadorX);
        printf("O: %s\n\n", jogadorO);

        printf("Tabuleiro:\n\n");
        mostrar_tabuleiro(tabuleiro);

        while (1) {
            printf("\nVez do jogador %c (%s):\n", simbolo, (simbolo == 'X') ? jogadorX : jogadorO);
            printf("Informe a linha (0-2): ");
            scanf("%d", &linha);
            printf("Informe a coluna (0-2): ");
            scanf("%d", &coluna);

            if (linha < 0 || linha >= TAM || coluna < 0 || coluna >= TAM) {
                printf("Posicao incorreta, escolha outra: (Linha: %d; Coluna: %d)\n", linha, coluna);
                continue;
            }

            if (tabuleiro[linha][coluna] != ' ') {
                printf("Esta posicao ja foi marcada, escolha outra: (Linha: %d; Coluna: %d)\n", linha, coluna);
                continue;
            }

            tabuleiro[linha][coluna] = simbolo;

            system("cls");

            mostrar_tabuleiro(tabuleiro);

            if (verificar_vitoria(tabuleiro, simbolo)) {
                printf("\nMuito bem, %s! Voce venceu a partida!\n", (simbolo == 'X') ? jogadorX : jogadorO);
                break;
            }

            turno++;
            if (turno == 9) {
                printf("\nEmpate! Nenhum dos jogadores venceram.\n");
                break;
            }

            simbolo = (simbolo == 'X') ? 'O' : 'X';
        }

        printf("\nDeseja jogar novamente? (S/N): ");
        scanf(" %c", &jogar_novamente);

        if (jogar_novamente == 'S' || jogar_novamente == 's') {
            printf("Deseja manter os mesmos jogadores? (S/N): ");
            scanf(" %c", &mesmos_jogadores);
            while (getchar() != '\n');
        }

    } while (jogar_novamente == 'S' || jogar_novamente == 's');

    printf("\nPrograma Encerrado!\n");
    return 0;
}

